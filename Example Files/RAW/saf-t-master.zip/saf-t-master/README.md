# saf-t
Used for publishing of Norwegian SAF-T Schemas, code lists, example files etc. See also http://www.skatteetaten.no/saf-t for further documentation and information.

The General Ledger Standard Accounts code lists are Copyright Regnskap Norge AS, 2018.  The General Ledger Standard Accounts may only be used in connection with SAF-T mapping. Other commercial use must be agreed upon with Regnskap Norge AS.  
